/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sourcePack;

import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;

/**
 *
 * @author Vasu Pal
 */
public class paymentdetails {
    
    public void insertDataCash(int a,int c, String p)
    {
        Connection conn=null;
        int amount=a;
        int cid=c;
        String ptype=p;
        try
        {
            conn=connectionprovider.getConnection();
            PreparedStatement stmt=conn.prepareStatement("insert into cashregister values(?,?,?)");
            stmt.setInt(1,cid);
            stmt.setInt(2, amount);
            stmt.setString(3, ptype);
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "PAYMENT DONE");
        }catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
}
