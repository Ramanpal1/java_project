/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sourcePack;
import java.sql.*;
import javax.swing.*;
/**
 *
 * @author Vasu Pal
 */
public class tabledetails {
    private int ticketno=0;
    public static void insertData(int c, String cn, int rn, String rt, int t)
    {
        Connection conn=null;
        int cid=c;
        String cname=cn;
        int rno=rn;
        String rtype=rt;
        int tno=t;
        try{
            conn=connectionprovider.getConnection();
            PreparedStatement stmt=conn.prepareStatement("insert into tablebook values(?,?,?,?,?)");
            stmt.setInt(1, cid);
            stmt.setString(2, cname);
            stmt.setInt(3, rno);
            stmt.setInt(5, tno);
            stmt.setString(4, rtype);
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null,"RECORD INSERTED");
        }catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void deleteData(int t)
    {
        int tno=t;
        Connection conn=null;
        try{
            conn=connectionprovider.getConnection();
            PreparedStatement stmt=conn.prepareStatement("delete from tablebook where tno="+t);
            stmt.executeQuery();
            JOptionPane.showMessageDialog(null, "RECORD DELETED");
        }catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
    }
public void getMaxTno()
{
    
    Connection conn=null;
    try{
            conn=connectionprovider.getConnection();
            Statement stmt=conn.createStatement();
            ResultSet rs=stmt.executeQuery("select max(tno) from tablebook");
            while(rs.next())
            {
                ticketno=rs.getInt(1);
                System.out.println(ticketno+"value in getMaxTno");
            }
            
        }catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
}
public int setMaxTno()
{
    System.out.println(ticketno+"value in SetMaxTno");
    return ticketno;
    
}
}
