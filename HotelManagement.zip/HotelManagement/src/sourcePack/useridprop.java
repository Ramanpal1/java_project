/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sourcePack;

/**
 *
 * @author Vasu Pal
 */
public class useridprop {
    static int userid;
    static int amount;
    public static void setuserid(int u)
    {
        userid=u;
        System.out.println(userid+" userid in setuserid");
    }
    public static int getuserid()
    {
        System.out.println(userid+" userid in getuserid");
        return userid;
    }
    public static void setamount(int a)
    {
        
        amount=a;
        System.out.println(amount+" amount in setamount");
    }
    public static int getamount()
    {
        System.out.println(amount+" amount in getamount");
        return amount;
        
    }
}
