/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sourcePack;

import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Vasu Pal
 */
public class user {
    public void insertData(String u, String p, String ut)
    {
        Connection conn=null;
        String uname=u;
        String pass=p;
        String utype=ut;
        try{
            conn=connectionprovider.getConnection();
            PreparedStatement stmt=conn.prepareStatement("insert into user_login(uname, pass, utype) values(?,?,?)");
             stmt.setString(1, uname);
             stmt.setString(2, pass);
             stmt.setString(3, utype);
             stmt.executeUpdate();
             JOptionPane.showMessageDialog( null, "NEW USER CREATED");
        }catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
}
