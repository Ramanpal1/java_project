/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sourcePack;
import java.sql.*;
import javax.swing.JOptionPane;
/**
 *
 * @author Vasu Pal
 */
public class roomdetails {
    static int amount;
    public static int getRoomNo(String rt)
    {
        String rtype=rt;
        {
        Connection conn=null;
        int x=0;
        try{
            conn=connectionprovider.getConnection();
            Statement stmt=conn.createStatement();
            ResultSet rs=stmt.executeQuery("select max(rno) from room where rtype='"+rtype+"'");
            while(rs.next())
            {
                x=rs.getInt(1);
            }
        }catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
        return x;
    }
    
    }
    public static int getAmount(String rt)
    {
        String rtype=rt;
        {
        Connection conn=null;
        
        try{
            conn=connectionprovider.getConnection();
            Statement stmt=conn.createStatement();
            ResultSet rs=stmt.executeQuery("select amount from roomdetails where rtype='"+rtype+"'");
            while(rs.next())
            {
                amount=rs.getInt(1);
            }
        }catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
        return amount;
    }
    
    }
    
   
}
