/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sourcePack;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Vasu Pal
 */
public class connectionprovider {
    public static Connection conn=null;
static
{
    try
    {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","oracle");
        System.out.println("connection established");
    }
    catch(Exception e)
    {
        System.out.println("" +e);
       
    }
    
}
public static Connection getConnection()
{
    

return conn;

}
    
}
