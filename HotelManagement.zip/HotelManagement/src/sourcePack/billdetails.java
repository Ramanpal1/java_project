/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sourcePack;

import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;

/**
 *
 * @author Vasu Pal
 */
public class billdetails {
    public void insertData(int c, String cn, String a, String e, String co,int n, int r, String rt, int t, int no, String id, String od,int am  )
    {
     int cid=c;
     String cname=cn;
     String addr=a;
     String email=e;
     String contact=co;
     int nop=n;
     int rno=r;
     String rtype=rt;
     int tno=t;
     int nod=no;
     String indate=id;
     String outdate=od;
     int amount=am;
     Connection conn=null;
     try{
         conn=connectionprovider.getConnection();
            PreparedStatement stmt=conn.prepareStatement("insert into billdetails values(?,?,?,?,?,?,?,?,?,?,?,?,?)");
             stmt.setInt(1, cid);
             stmt.setString(2, cname);
             stmt.setString(3, addr);
             stmt.setString(4, email);
             stmt.setString(5, contact);
             stmt.setInt(6, nop);
             stmt.setString(11, indate);
             stmt.setString(12, outdate);
             stmt.setString(8, rtype);
             stmt.setInt(9, tno);
             stmt.setInt(7, rno);
             stmt.setInt(10, nod);
             stmt.setInt(13, amount);
             stmt.executeUpdate();
             JOptionPane.showMessageDialog( null, "DATA RECORDED");
     }catch(Exception z)
     {
         JOptionPane.showMessageDialog(null, z);
     }
     
     
    }
    
}
