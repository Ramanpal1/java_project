/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sourcePack;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Vasu Pal
 */
public class booking {
    public void insertData(int c, String cn, String a, String e, String p, int no, String id, String od, String rt, int r,int np,int am)
    {
        Connection conn=null;
        int cid=c;
        String cname=cn;
        String addr=a;
        String email=e;
        String contact=p;
        int nod=no;
        String indate=id;
        String outdate=od;
        int rno=r;
        String rtype=rt;
        int nop=np;
        int amount=am;
        try{
            conn=connectionprovider.getConnection();
            PreparedStatement stmt=conn.prepareStatement("insert into room values(?,?,?,?,?,?,?,?,?,?,?,?)");
             stmt.setInt(1, cid);
             stmt.setString(2, cname);
             stmt.setString(3, addr);
             stmt.setString(4, email);
             stmt.setString(5, contact);
             stmt.setInt(6, nod);
             stmt.setString(7, indate);
             stmt.setString(8, outdate);
             stmt.setString(9, rtype);
             stmt.setInt(10, rno);
             stmt.setInt(11, nop);
             stmt.setInt(12, amount);
             stmt.executeUpdate();
             JOptionPane.showMessageDialog( null, "DATA RECORDED");
        }catch(Exception z)
        {
            JOptionPane.showMessageDialog(null, z);
        }
    }
    public static int getMaxid()
    {
        Connection conn=null;
        int x=0;
        try{
            conn=connectionprovider.getConnection();
            Statement stmt=conn.createStatement();
            ResultSet rs=stmt.executeQuery("select max(cid) from room");
            while(rs.next())
            {
                x=rs.getInt(1);
            }
        }catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
        return x;
    }
    public void deleteData(int c)
    {
        int cid=c;
        Connection conn=null;
        try{
            conn=connectionprovider.getConnection();
            PreparedStatement stmt=conn.prepareStatement("delete from room where cid="+cid);
            stmt.executeQuery();
            JOptionPane.showMessageDialog(null, "RECORD DELETED");
        }catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
    }
}
